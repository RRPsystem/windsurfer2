<div class="wrap">
    <h1>rbsTravel</h1>

    <iframe id="iframe-travel" src="/" style="width: 100%; height: 100vh;"></iframe>
</div>