<div class="wrap">
    <h1>rbsTravel - Test Page</h1>
    
<?php

// $json_ideas = rbstravel_get_ideas(array(), true);
// $ideas = rbstravel_get_ideas();
// echo '<pre>' . print_r($ideas, true) . '</pre>';


\rbstravel_get_filter_html('location');

// die('rbstravel_get_location_filter_html');

?>

<style>
    .test_filter {
        margin-left: 25px;
    }
</style>
</div>