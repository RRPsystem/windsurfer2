<div id="rbstravel-travel-details" class="rbstravel-popup-window" style="display: none;">
    <button data-target="rbstravel-travel-details" type="button" name="close_popup_window" value="close" class="rbstravel-popup-window__close button-secondary"><?php _e('Close', 'rbs-travel'); ?></button>
    <h2><?php _e('Travel Details', 'rbs-travel'); ?></h2>
    
    <pre id="rbstravel-travel-details__content"></pre>
</div>