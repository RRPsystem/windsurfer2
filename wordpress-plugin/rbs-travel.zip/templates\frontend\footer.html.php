<footer id="rbstravel-footer" class="site-footer">
    <div class="site-info">
        <p><a href="https://www.robas.com" target="_blank">Robas Internet Oplossingen &copy; <?php echo date('Y'); ?></a> <span>RBS Travel</span></p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
