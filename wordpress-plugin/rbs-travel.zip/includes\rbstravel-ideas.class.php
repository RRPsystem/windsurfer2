<?php
namespace RBS_TRAVEL\INCLUDES;
defined('RBS_TRAVEL') or die();

/**
 * @todo:
 * - [ ] 
 */


if (!class_exists('RBS_TRAVEL\INCLUDES\RBS_TRAVEL_Ideas')) {
    
    
    class RBS_TRAVEL_Ideas {
	
    }
    
}